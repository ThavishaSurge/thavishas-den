<?php
/**
 * Child theme functions
 */
function den_enqueue_assets() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'den-fonts', 'https://fonts.example.com/inter.css', array(), null );
    wp_enqueue_script( 'den-main', get_stylesheet_directory_uri() . '/assets/js/main.js', array( 'jquery' ), '1.1', true );
}
add_action( 'wp_enqueue_scripts', 'den_enqueue_assets' );

function den_footer_text() {
    return 'Copyright ' . date( 'Y' ) . ' Den Studio';
}
add_filter( 'astra_footer_copyright', 'den_footer_text' );

function den_product_badge_shortcode( $atts ) {
    $atts = shortcode_atts( array( 'label' => 'New' ), $atts );
    return '<span class="den-badge">' . esc_html( $atts['label'] ) . '</span>';
}
add_shortcode( 'den_badge', 'den_product_badge_shortcode' );
