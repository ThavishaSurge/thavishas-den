document.addEventListener('DOMContentLoaded', function () {
  console.log('den ready');
  initMenu();
});

function initMenu() {
  document.querySelector('.menu-toggle')?.addEventListener('click', () => document.body.classList.toggle('menu-open'));
}
