<?php get_header(); ?>
<main>
  <h1><?php the_title(); ?></h1>
</main>
