<?php
add_filter( 'woocommerce_sale_flash', function () { return '<span>Deal</span>'; } );
