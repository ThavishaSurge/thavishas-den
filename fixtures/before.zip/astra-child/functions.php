<?php
/**
 * Child theme functions
 */
function den_enqueue_assets() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_script( 'den-main', get_stylesheet_directory_uri() . '/js/main.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'den_enqueue_assets' );

function den_footer_text() {
    return 'Copyright 2025';
}
add_filter( 'astra_footer_copyright', 'den_footer_text' );

function den_legacy_banner() {
    echo '<div class="old-banner">Sale!</div>';
}
add_action( 'wp_body_open', 'den_legacy_banner' );
